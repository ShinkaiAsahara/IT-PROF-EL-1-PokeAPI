let pokemons = [];
const poke_container = document.getElementById("poke_container");
const url = "https://pokeapi.co/api/v2/pokemon";
const pokemons_number = 152;
const search = document.getElementById("search");
const form = document.getElementById("form");
const modal = document.getElementById("modal");
const modalContent = document.getElementById("modalContent");
const closeModal = document.getElementById("closeModal");

// fetch all Pokémon
const fetchPokemons = async () => {
    for (let i = 1; i <= pokemons_number; i++) {
        await getAllPokemon(i);
    }
    pokemons.forEach((pokemon) => createPokemonCard(pokemon));
};

// remove pokemon card from display
const removePokemon = () => {
    const pokemonEls = document.getElementsByClassName("pokemon");
    while (pokemonEls.length > 0) {
        pokemonEls[0].remove();
    }
};

// get pokemon by name
const getPokemon = async (name) => {
    const searchPokemons = pokemons.filter((poke) => poke.name.toLowerCase() === name.toLowerCase());
    removePokemon();
    if (searchPokemons.length > 0) {
        searchPokemons.forEach((pokemon) => createPokemonCard(pokemon));
    } else {
        console.log(`No Pokemon found with the name: ${name}`);
    }
};

// fetch Pokemon data from the API
const getAllPokemon = async (id) => {
    const res = await fetch(`${url}/${id}`);
    if (res.ok) {
        const pokemon = await res.json();
        pokemons.push(pokemon);
    } else {
        console.error(`Failed to fetch -> : ${id}`);
    }
};

// fetch Pokemon data on page load
fetchPokemons();

// create Pokemon card container
function createPokemonCard(pokemon) {
    const pokemonEl = document.createElement("div");
    pokemonEl.classList.add("pokemon", "rounded-lg", "bg-gray-200", "shadow-xl", "p-4", "flex", "flex-col", "items-center", "text-center", "h-full", "cursor-pointer", "border-2" , "border-black");

    const poke_types = pokemon.types.map((el) => el.type.name).join(", ");
    const name = pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1);
    const stats = pokemon.stats.map(stat => `${stat.stat.name}: ${stat.base_stat}`).join(", ");
    const description = `This is a ${name}. It has the following stats: ${stats}.`;

    const pokeInnerHTML = `
        <div class="flex mb-2">
            <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png" alt="${name}" class="w-24 h-24 object-contain" onerror="this.onerror=null; this.src='https://via.placeholder.com/150';"/>
        </div>
        <div class="info">
            <h3 class="text-xl font-bold font-serif">${name}</h3>
            <small class="text-lg font-meduim font-serif  text-red-700"><span>${poke_types}</span></small>
        </div>
    `;

    pokemonEl.innerHTML = pokeInnerHTML;
    pokemonEl.addEventListener("click", () => showModal(name, description));
    poke_container.appendChild(pokemonEl);
}

// show modal with Pokemon details and description
function showModal(name, description) {
    modalContent.innerHTML = `<h2 class="text-xl text-center font-bold font-serif pt-3 pb-3">${name}</h2><p>${description}</p>`;
    modal.classList.remove("hidden");
    modal.classList.add("active");
}

// Close modal
closeModal.addEventListener("click", () => {
    modal.classList.remove("active");
    modal.classList.add("closing");
    setTimeout(() => {
        modal.classList.remove("closing");
        modal.classList.add("hidden");
    },); 
});

// Search functionality
form.addEventListener("submit", (e) => {
    e.preventDefault();
    const searchItem = search.value.trim();
    if (searchItem) {
        getPokemon(searchItem);
        search.value = "";
    } else {
        removePokemon();
        fetchPokemons();
    }

});


